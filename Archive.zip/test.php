<?php

/*MySQL Code*/
$servername = "localhost";
$username = "root";
$password = "test";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully!";
echo "<br>";


$sql = "SELECT id, Donor_ID, Ticket_Type_ID FROM Tickets";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each rows
  while($row = $result->fetch_assoc()) {
      echo "id: " . $row["id"] . $row["Donor_ID"]. " " . $row["Ticket_Type_ID"]. "<br>";
  }
} else {
  echo "0 results";
}
?>
